@echo off
title Creando ejecutable de Nomina App...
color 1F
echo.
echo  ================================================
echo    Creando ejecutable  -  Nomina App
echo    Este proceso tarda entre 1 y 3 minutos.
echo  ================================================
echo.

:: Verificar Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Python no esta instalado.
    echo.
    echo  Por favor:
    echo    1. Ve a https://python.org/downloads
    echo    2. Instala Python
    echo    3. Marca la casilla "Add Python to PATH"
    echo    4. Reinicia la computadora
    echo    5. Vuelve a ejecutar este archivo
    echo.
    pause
    exit /b 1
)

echo  [1/3] Instalando dependencias...
pip install pandas openpyxl pyinstaller -q --no-warn-script-location
echo       Listo.
echo.

echo  [2/3] Compilando el ejecutable (puede tardar unos minutos)...
pyinstaller --onefile --windowed --name "Nomina App" --hidden-import=nomina --add-data "lacima.csv;." --add-data "rc.csv;." "%~dp0app.py"
if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Ocurrio un problema al compilar.
    echo  Intenta cerrar otros programas y volver a ejecutar.
    pause
    exit /b 1
)
echo       Listo.
echo.

echo  [3/3] Copiando archivos necesarios...
copy "%~dp0lacima.csv"  "%~dp0dist\lacima.csv"  >nul
copy "%~dp0rc.csv"      "%~dp0dist\rc.csv"      >nul
echo       Listo.
echo.

echo  ================================================
echo   TERMINADO
echo.
echo   Tu ejecutable esta en la carpeta "dist":
echo   %~dp0dist\Nomina App.exe
echo.
echo   Para compartirlo, copia TODA la carpeta "dist"
echo   (incluye lacima.csv y rc.csv adentro).
echo  ================================================
echo.
pause
