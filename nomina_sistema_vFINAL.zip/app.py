#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""app.py — Procesador de Nómina con gestión de empleados."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading, os, sys, json, io, contextlib, re

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if getattr(sys, 'frozen', False):
    SCRIPT_DIR = os.path.dirname(sys.executable)
else:
    sys.path.insert(0, SCRIPT_DIR)

try:
    import pandas as pd
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pandas', 'openpyxl', '-q'])
    import pandas as pd

EMPRESAS_JSON = os.path.join(SCRIPT_DIR, 'empresas.json')
TIPOS = ['Permanente', 'Eventual']

# ── Colores ────────────────────────────────────────────────────────────────
AZ  = '#1A3A5C'; AZM = '#2563EB'; VE  = '#16A34A'; VEL = '#DCFCE7'
RO  = '#DC2626'; ROL = '#FEE2E2'; NA  = '#D97706'; NAL = '#FEF9C3'
GF  = '#F8FAFC'; GB  = '#CBD5E1'; GT  = '#334155'; BL  = '#FFFFFF'
NE  = '#0F172A'; MO  = '#7C3AED'; MOL = '#EDE9FE'
AZL2= '#DBEAFE'; GG  = '#F1F5F9'; GGD = '#E2E8F0'

# ════════════════════════════════════════════════════════════════════════════
#  BASE DE DATOS DE EMPLEADOS
# ════════════════════════════════════════════════════════════════════════════

class EmpleadoDB:
    def __init__(self):
        self._cargar_empresas()

    def _cargar_empresas(self):
        if os.path.exists(EMPRESAS_JSON):
            with open(EMPRESAS_JSON, 'r', encoding='utf-8') as f:
                self.empresas = json.load(f)
        else:
            self.empresas = {'La Cima': 'lacima.csv', 'RC': 'rc.csv'}
            self._guardar_empresas()

    def _guardar_empresas(self):
        with open(EMPRESAS_JSON, 'w', encoding='utf-8') as f:
            json.dump(self.empresas, f, ensure_ascii=False, indent=2)

    def nombres_empresas(self):
        return list(self.empresas.keys())

    def ruta(self, empresa):
        return os.path.join(SCRIPT_DIR, self.empresas[empresa])

    def cargar_empresa(self, empresa):
        ruta = self.ruta(empresa)
        if not os.path.exists(ruta):
            return pd.DataFrame(columns=['ID','Nombre','Salario Diario','SBC','Tipo'])
        df = pd.read_csv(ruta, sep='\t', dtype=str).fillna('')
        df.columns = [c.strip() for c in df.columns]
        for col in ('SBC', 'Tipo'):
            if col not in df.columns:
                df[col] = ''
        return df

    def guardar_empresa(self, empresa, df):
        cols = [c for c in ['ID','Nombre','Salario Diario','SBC','Tipo'] if c in df.columns]
        df[cols].to_csv(self.ruta(empresa), sep='\t', index=False)

    def cargar_todos(self):
        dfs = []
        for emp in self.empresas:
            df = self.cargar_empresa(emp)
            df['Empresa'] = emp
            dfs.append(df)
        if not dfs:
            return pd.DataFrame(columns=['ID','Nombre','Salario Diario','SBC','Tipo','Empresa'])
        out = pd.concat(dfs, ignore_index=True)
        for c in ['ID','Nombre','Salario Diario','SBC','Tipo','Empresa']:
            if c not in out.columns: out[c] = ''
        return out.fillna('')

    def id_existe(self, id_, empresa):
        df = self.cargar_empresa(empresa)
        return str(id_).strip() in df['ID'].str.strip().values

    def añadir(self, id_, nombre, empresa, salario, sbc='', tipo=''):
        if self.id_existe(id_, empresa):
            raise ValueError(f"El ID '{id_}' ya existe en {empresa}.")
        df = self.cargar_empresa(empresa)
        nueva = pd.DataFrame([{'ID': str(id_).strip(),
                                'Nombre': str(nombre).strip().upper(),
                                'Salario Diario': str(salario).strip(),
                                'SBC': str(sbc).strip(),
                                'Tipo': str(tipo).strip()}])
        self.guardar_empresa(empresa, pd.concat([df, nueva], ignore_index=True))

    def editar(self, id_, empresa, datos):
        # 1. Actualizar el CSV de la empresa
        df = self.cargar_empresa(empresa)
        mask = df['ID'].str.strip() == str(id_).strip()
        for campo, val in datos.items():
            if campo in df.columns:
                df.loc[mask, campo] = str(val).strip()
        self.guardar_empresa(empresa, df)

        # 2. Reflejar los cambios en mapeo_empleados.csv (solo la fila del empleado)
        mapeo_path = os.path.join(SCRIPT_DIR, 'mapeo_empleados.csv')
        if not os.path.exists(mapeo_path):
            return
        try:
            df_m = pd.read_csv(mapeo_path, dtype=str).fillna('')
            mask_m = ((df_m['CONTPAQ_ID'].str.strip()     == str(id_).strip()) &
                      (df_m['CONTPAQ_Empresa'].str.strip() == str(empresa).strip()))
            # Equivalencia campo CSV → columna en el mapeo
            campo_a_mapeo = {
                'Nombre':         'CONTPAQ_Nombre',
                'Salario Diario': 'CONTPAQ_Salario',
                'SBC':            'CONTPAQ_SBC',
                'Tipo':           'CONTPAQ_Tipo',
            }
            for campo, val in datos.items():
                col_m = campo_a_mapeo.get(campo)
                if col_m and col_m in df_m.columns:
                    df_m.loc[mask_m, col_m] = str(val).strip()
            df_m.to_csv(mapeo_path, index=False, encoding='utf-8-sig')
        except Exception:
            pass   # Si falla el mapeo no es crítico; el CSV sí quedó guardado

    def dar_de_baja(self, id_, empresa):
        df = self.cargar_empresa(empresa)
        self.guardar_empresa(empresa, df[df['ID'].str.strip() != str(id_).strip()])

    def mover(self, id_orig, emp_orig, emp_dest, id_nuevo=None):
        df_o = self.cargar_empresa(emp_orig)
        mask = df_o['ID'].str.strip() == str(id_orig).strip()
        row  = df_o[mask].copy()
        if row.empty: raise ValueError(f"Empleado '{id_orig}' no encontrado en {emp_orig}.")
        if id_nuevo and str(id_nuevo).strip() != str(id_orig).strip():
            row['ID'] = str(id_nuevo).strip()
        nid = row['ID'].iloc[0]
        if self.id_existe(nid, emp_dest):
            raise ValueError(f"El ID '{nid}' ya existe en {emp_dest}.")
        self.guardar_empresa(emp_orig, df_o[~mask])
        self.guardar_empresa(emp_dest, pd.concat([self.cargar_empresa(emp_dest), row], ignore_index=True))
        return row['Nombre'].iloc[0]

    def añadir_empresa(self, nombre, df_emp):
        if nombre in self.empresas: raise ValueError(f"'{nombre}' ya existe.")
        archivo = re.sub(r'[^a-zA-Z0-9]', '_', nombre).lower() + '.csv'
        self.empresas[nombre] = archivo
        self._guardar_empresas()
        self.guardar_empresa(nombre, df_emp)
        return archivo

    def eliminar_empresa(self, nombre, borrar_archivo=True):
        if nombre not in self.empresas:
            raise ValueError(f"'{nombre}' no existe.")
        archivo = self.empresas[nombre]
        ruta = os.path.join(SCRIPT_DIR, archivo)
        del self.empresas[nombre]
        self._guardar_empresas()
        if borrar_archivo and os.path.exists(ruta):
            os.remove(ruta)
        return archivo

    @staticmethod
    def parsear_pegar(texto, tipo_default=''):
        """Parsea texto pegado del CONTPAQi. Retorna (df, error_msg)."""
        if not texto.strip(): return None, "No hay datos."
        lineas = [l for l in texto.strip().splitlines() if l.strip()]
        if len(lineas) < 2: return None, "Se necesitan al menos encabezado + 1 fila."
        sep = '\t' if '\t' in lineas[0] else None
        split = (lambda l: [p.strip() for p in l.split('\t')]) if sep else (lambda l: l.split())
        header, filas = None, []
        for i, linea in enumerate(lineas):
            partes = split(linea)
            if i == 0:
                p0 = partes[0].upper().replace(' ','')
                if p0 in ('ID','COD','CODIGO','CLAVE','#','NO','NUM'):
                    header = [p.upper().replace(' ','') for p in partes]; continue
                else:
                    header = ['ID','NOMBRE','SALARIOD']
            if len(partes) < 2: continue
            f = {'ID':'','Nombre':'','Salario Diario':'','SBC':'','Tipo': tipo_default}
            if header:
                for j,h in enumerate(header):
                    if j >= len(partes): break
                    if h in ('ID','COD','CODIGO','CLAVE','#','NO','NUM'): f['ID']=partes[j]
                    elif h=='NOMBRE': f['Nombre']=partes[j]
                    elif 'SALARIOD' in h or h=='SALARIO': f['Salario Diario']=partes[j]
                    elif any(x in h for x in ('SBC','COTIZ','BASE')): f['SBC']=partes[j]
            else:
                f['ID']=partes[0]; f['Nombre']=' '.join(partes[1:-1]); f['Salario Diario']=partes[-1]
            if f['ID'] and f['Nombre']: filas.append(f)
        if not filas: return None, "No se detectaron empleados válidos."
        return pd.DataFrame(filas), None


# ════════════════════════════════════════════════════════════════════════════
#  HELPERS UI
# ════════════════════════════════════════════════════════════════════════════

def _centrar(win, w, h):
    win.update_idletasks()
    x = (win.winfo_screenwidth()  // 2) - (w // 2)
    y = (win.winfo_screenheight() // 2) - (h // 2)
    win.geometry(f'{w}x{h}+{x}+{y}')

def _lbl(p, t, bold=False, fg=GT, bg=BL, size=9):
    return tk.Label(p, text=t, bg=bg, fg=fg,
                    font=('Segoe UI', size, 'bold' if bold else 'normal'))

def _entry(p, var=None, w=28, readonly=False):
    e = tk.Entry(p, textvariable=var, font=('Segoe UI', 10),
                 relief='solid', bd=1, bg=GGD if readonly else GF, width=w)
    if readonly: e.configure(state='disabled')
    return e

def _boton(p, t, cmd, bg=AZM, fg=BL, **kw):
    return tk.Button(p, text=t, command=cmd, bg=bg, fg=fg,
                     font=('Segoe UI', 9, 'bold'), relief='flat',
                     padx=12, pady=6, cursor='hand2',
                     activebackground=bg, activeforeground=fg, **kw)

def _sep_titulo(parent, texto, color=AZ, bg=BL):
    """Franja de título de sección dentro de un diálogo."""
    f = tk.Frame(parent, bg=color, padx=10, pady=5)
    f.pack(fill='x', pady=(10,4))
    tk.Label(f, text=texto, bg=color, fg=BL,
             font=('Segoe UI', 9, 'bold')).pack(anchor='w')


# ════════════════════════════════════════════════════════════════════════════
#  DIÁLOGOS
# ════════════════════════════════════════════════════════════════════════════

class DlgEmpleado(tk.Toplevel):
    """Añadir o editar un empleado."""
    def __init__(self, parent, db, modo='añadir', empleado=None):
        super().__init__(parent)
        self.db = db; self.ok = False; self.modo = modo
        self.emp = empleado or {}
        self.title('Añadir empleado' if modo == 'añadir' else 'Editar empleado')
        self.configure(bg=BL); self.resizable(False, False); self.grab_set()

        tk.Frame(self, bg=VE if modo=='añadir' else AZM, height=6).pack(side='top', fill='x')
        f = tk.Frame(self, bg=BL); f.pack(fill='both', expand=True, padx=18, pady=14)

        self.v_empresa = tk.StringVar(value=self.emp.get('Empresa', db.nombres_empresas()[0] if db.nombres_empresas() else ''))
        self.v_tipo    = tk.StringVar(value=self.emp.get('Tipo', 'Permanente'))
        self.v_id      = tk.StringVar(value=self.emp.get('ID', ''))
        self.v_nombre  = tk.StringVar(value=self.emp.get('Nombre', ''))
        self.v_salario = tk.StringVar(value=self.emp.get('Salario Diario', ''))
        self.v_sbc     = tk.StringVar(value=self.emp.get('SBC', ''))

        campos = [
            ('Empresa *',        'combo',  self.v_empresa,  False, db.nombres_empresas()),
            ('Tipo *',           'combo',  self.v_tipo,     False, TIPOS),
            ('ID del empleado *','entry',  self.v_id,       modo=='editar', None),
            ('Nombre completo *','entry',  self.v_nombre,   False, None),
            ('Salario Diario *', 'entry',  self.v_salario,  False, None),
            ('SBC',              'entry',  self.v_sbc,      False, None),
        ]
        for lbl_txt, tipo_w, var, rdonly, vals in campos:
            r = tk.Frame(f, bg=BL); r.pack(fill='x', pady=3)
            _lbl(r, lbl_txt, bold=True).pack(anchor='w')
            if tipo_w == 'combo':
                cb = ttk.Combobox(r, textvariable=var, values=vals,
                                   state='readonly', width=32)
                cb.pack(fill='x', pady=2)
            else:
                _entry(r, var, w=38, readonly=rdonly).pack(fill='x', pady=2, ipady=4)

        fb = tk.Frame(f, bg=BL); fb.pack(fill='x', pady=(14,0))
        _boton(fb, 'Cancelar', self.destroy, bg='#64748B').pack(side='left')
        _boton(fb, '  Guardar  ', self._guardar,
               bg=VE if modo=='añadir' else AZM).pack(side='right')

        _centrar(self, 430, 460)
        self.wait_window()

    def _guardar(self):
        empresa = self.v_empresa.get().strip()
        tipo    = self.v_tipo.get().strip()
        id_     = self.v_id.get().strip()
        nombre  = self.v_nombre.get().strip()
        salario = self.v_salario.get().strip()
        sbc     = self.v_sbc.get().strip()
        if not all([empresa, tipo, id_, nombre, salario]):
            messagebox.showwarning('Campos requeridos',
                                    'Empresa, Tipo, ID, Nombre y Salario son obligatorios.', parent=self)
            return
        try:
            float(salario.replace(',','.'))
        except ValueError:
            messagebox.showwarning('Salario inválido', 'El salario debe ser un número.', parent=self)
            return
        try:
            if self.modo == 'añadir':
                self.db.añadir(id_, nombre, empresa, salario, sbc, tipo)
            else:
                self.db.editar(self.emp['ID'], self.emp['Empresa'],
                               {'Nombre': nombre, 'Salario Diario': salario,
                                'SBC': sbc, 'Tipo': tipo})
            self.ok = True; self.destroy()
        except ValueError as e:
            messagebox.showerror('Error', str(e), parent=self)


class DlgMover(tk.Toplevel):
    def __init__(self, parent, db, empleado):
        super().__init__(parent)
        self.db = db; self.emp = empleado; self.ok = False
        self.title('Mover empleado de empresa')
        self.configure(bg=BL); self.resizable(False, False); self.grab_set()

        tk.Frame(self, bg=MO, height=6).pack(side='top', fill='x')
        f = tk.Frame(self, bg=BL); f.pack(fill='both', expand=True, padx=18, pady=14)

        info = tk.Frame(f, bg=MOL, padx=12, pady=10); info.pack(fill='x', pady=(0,12))
        tk.Label(info, text=empleado['Nombre'], bg=MOL, fg=MO,
                 font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        tk.Label(info, text=f"ID: {empleado['ID']}   Empresa: {empleado['Empresa']}   Tipo: {empleado.get('Tipo','—')}",
                 bg=MOL, fg=GT, font=('Segoe UI', 9)).pack(anchor='w')

        self.v_dest = tk.StringVar()
        self.v_nid  = tk.StringVar(value=empleado['ID'])
        self.v_tipo = tk.StringVar(value=empleado.get('Tipo', 'Permanente'))

        for lbl_txt, var, vals in [
            ('Empresa destino *', self.v_dest,
             [e for e in db.nombres_empresas() if e != empleado['Empresa']]),
            ('Tipo en empresa destino', self.v_tipo, TIPOS),
        ]:
            r = tk.Frame(f, bg=BL); r.pack(fill='x', pady=4)
            _lbl(r, lbl_txt, bold=True).pack(anchor='w')
            cb = ttk.Combobox(r, textvariable=var, values=vals, state='readonly', width=32)
            cb.pack(fill='x', pady=2)
        if [e for e in db.nombres_empresas() if e != empleado['Empresa']]:
            self.v_dest.set([e for e in db.nombres_empresas() if e != empleado['Empresa']][0])

        r2 = tk.Frame(f, bg=BL); r2.pack(fill='x', pady=4)
        _lbl(r2, 'Nuevo ID (si cambia al pasar a permanente)', bold=True).pack(anchor='w')
        _lbl(r2, 'Deja igual si el ID no cambia', fg='#94A3B8').pack(anchor='w')
        _entry(r2, self.v_nid, w=20).pack(anchor='w', pady=2, ipady=4)

        fb = tk.Frame(f, bg=BL); fb.pack(fill='x', pady=(14,0))
        _boton(fb, 'Cancelar', self.destroy, bg='#64748B').pack(side='left')
        _boton(fb, '↔  Mover', self._mover, bg=MO).pack(side='right')

        _centrar(self, 430, 360)
        self.wait_window()

    def _mover(self):
        dest = self.v_dest.get().strip()
        nid  = self.v_nid.get().strip()
        tipo = self.v_tipo.get().strip()
        if not dest:
            messagebox.showwarning('Falta empresa', 'Selecciona la empresa destino.', parent=self); return
        try:
            self.db.mover(self.emp['ID'], self.emp['Empresa'], dest,
                          nid if nid != self.emp['ID'] else None)
            # Actualizar tipo en destino si cambió
            if tipo != self.emp.get('Tipo', ''):
                id_final = nid if nid != self.emp['ID'] else self.emp['ID']
                self.db.editar(id_final, dest, {'Tipo': tipo})
            self.ok = True; self.destroy()
        except ValueError as e:
            messagebox.showerror('Error', str(e), parent=self)


class DlgEmpresa(tk.Toplevel):
    """Añadir empresa con dos listas: primero eventuales, luego permanentes."""
    def __init__(self, parent, db):
        super().__init__(parent)
        self.db = db; self.ok = False
        self.title('Añadir nueva empresa')
        self.configure(bg=BL); self.resizable(True, True); self.grab_set()

        tk.Frame(self, bg=NA, height=6).pack(side='top', fill='x')
        f = tk.Frame(self, bg=BL); f.pack(fill='both', expand=True, padx=18, pady=10)

        # Nombre de empresa
        r_nom = tk.Frame(f, bg=BL); r_nom.pack(fill='x', pady=(0,4))
        _lbl(r_nom, 'Nombre de la empresa *', bold=True).pack(anchor='w')
        self.v_nombre = tk.StringVar()
        _entry(r_nom, self.v_nombre, w=40).pack(fill='x', pady=2, ipady=4)

        # ── Sección EVENTUALES ─────────────────────────────────────────────
        _sep_titulo(f, '1 · EVENTUALES — Pega aquí la lista de CONTPAQi', color='#92400E')
        _lbl(f, 'Formato: cualquier tabla con columnas ID, Nombre, Salario (separado por tabs)',
             fg='#64748B').pack(anchor='w')
        self.txt_ev = scrolledtext.ScrolledText(f, height=7, font=('Consolas', 9),
                                                 bg=GF, relief='solid', bd=1)
        self.txt_ev.pack(fill='x', pady=(4,0))
        self.lbl_prev_ev = tk.Label(f, text='', bg=BL, font=('Segoe UI', 9, 'bold'))
        self.lbl_prev_ev.pack(anchor='w', pady=(2,0))
        self.txt_ev.bind('<KeyRelease>', lambda e: self._preview(self.txt_ev, self.lbl_prev_ev))
        self.txt_ev.bind('<<Paste>>', lambda e: self.after(50, lambda: self._preview(self.txt_ev, self.lbl_prev_ev)))

        # ── Sección PERMANENTES ────────────────────────────────────────────
        _sep_titulo(f, '2 · PERMANENTES — Pega aquí la lista de CONTPAQi', color=AZ)
        _lbl(f, 'Formato: igual que la de eventuales',
             fg='#64748B').pack(anchor='w')
        self.txt_pe = scrolledtext.ScrolledText(f, height=7, font=('Consolas', 9),
                                                 bg=GF, relief='solid', bd=1)
        self.txt_pe.pack(fill='x', pady=(4,0))
        self.lbl_prev_pe = tk.Label(f, text='', bg=BL, font=('Segoe UI', 9, 'bold'))
        self.lbl_prev_pe.pack(anchor='w', pady=(2,0))
        self.txt_pe.bind('<KeyRelease>', lambda e: self._preview(self.txt_pe, self.lbl_prev_pe))
        self.txt_pe.bind('<<Paste>>', lambda e: self.after(50, lambda: self._preview(self.txt_pe, self.lbl_prev_pe)))

        # ── Total + botones ────────────────────────────────────────────────
        self.lbl_total = tk.Label(f, text='', bg=BL, font=('Segoe UI', 10, 'bold'), fg=VE)
        self.lbl_total.pack(anchor='w', pady=(8,0))

        fb = tk.Frame(f, bg=BL); fb.pack(fill='x', pady=(8,0))
        _boton(fb, 'Cancelar', self.destroy, bg='#64748B').pack(side='left')
        _boton(fb, '+ Añadir empresa', self._añadir, bg=NA).pack(side='right')

        _centrar(self, 640, 680)
        self.df_ev = None; self.df_pe = None
        self.wait_window()

    def _preview(self, txt_widget, lbl_widget):
        texto = txt_widget.get('1.0', 'end')
        tipo  = 'Eventual' if txt_widget is self.txt_ev else 'Permanente'
        df, err = EmpleadoDB.parsear_pegar(texto, tipo_default=tipo)
        if err:
            lbl_widget.config(text=f'⚠  {err}', fg=RO)
            if txt_widget is self.txt_ev: self.df_ev = None
            else: self.df_pe = None
        else:
            lbl_widget.config(text=f'✓  {len(df)} {tipo.lower()}s detectados', fg=VE)
            if txt_widget is self.txt_ev: self.df_ev = df
            else: self.df_pe = df
        # Actualizar total
        n_ev = len(self.df_ev) if self.df_ev is not None else 0
        n_pe = len(self.df_pe) if self.df_pe is not None else 0
        if n_ev + n_pe > 0:
            self.lbl_total.config(
                text=f'Total: {n_ev} eventual(es) + {n_pe} permanente(s) = {n_ev+n_pe} empleados')
        else:
            self.lbl_total.config(text='')

    def _añadir(self):
        nombre = self.v_nombre.get().strip()
        if not nombre:
            messagebox.showwarning('Nombre requerido', 'Escribe el nombre de la empresa.', parent=self); return
        if self.df_ev is None and self.df_pe is None:
            messagebox.showwarning('Sin datos', 'Pega al menos una lista de empleados.', parent=self); return
        partes = []
        if self.df_ev is not None: partes.append(self.df_ev)
        if self.df_pe is not None: partes.append(self.df_pe)
        import pandas as pd
        df_total = pd.concat(partes, ignore_index=True)
        try:
            arch = self.db.añadir_empresa(nombre, df_total)
            n_ev = len(self.df_ev) if self.df_ev is not None else 0
            n_pe = len(self.df_pe) if self.df_pe is not None else 0
            messagebox.showinfo('Empresa añadida',
                f'✓  Empresa "{nombre}" creada.\n\n'
                f'   {n_ev} eventual(es)\n'
                f'   {n_pe} permanente(s)\n'
                f'   Archivo: {arch}', parent=self)
            self.ok = True; self.destroy()
        except ValueError as e:
            messagebox.showerror('Error', str(e), parent=self)


class DlgEliminarEmpresa(tk.Toplevel):
    """Confirmación para eliminar una empresa completa."""
    def __init__(self, parent, db):
        super().__init__(parent)
        self.db = db; self.ok = False
        self.title('Eliminar empresa')
        self.configure(bg=BL); self.resizable(False, False); self.grab_set()

        tk.Frame(self, bg=RO, height=6).pack(side='top', fill='x')
        f = tk.Frame(self, bg=BL); f.pack(fill='both', expand=True, padx=18, pady=14)

        r = tk.Frame(f, bg=BL); r.pack(fill='x', pady=(0,6))
        _lbl(r, 'Empresa a eliminar *', bold=True).pack(anchor='w')
        self.v_emp = tk.StringVar()
        empresas = db.nombres_empresas()
        cb = ttk.Combobox(r, textvariable=self.v_emp, values=empresas,
                           state='readonly', width=32)
        cb.pack(fill='x', pady=2)
        if empresas: self.v_emp.set(empresas[0])
        cb.bind('<<ComboboxSelected>>', lambda e: self._actualizar_info())

        self.lbl_info = tk.Label(f, text='', bg=ROL, fg=RO, font=('Segoe UI',9,'bold'),
                                  justify='left', anchor='w', padx=10, pady=8)
        self.lbl_info.pack(fill='x', pady=(8,4))

        r2 = tk.Frame(f, bg=BL); r2.pack(fill='x', pady=(8,2))
        _lbl(r2, 'Para confirmar, escribe el nombre exacto de la empresa:',
             bold=True, fg=RO).pack(anchor='w')
        self.v_confirma = tk.StringVar()
        _entry(r2, self.v_confirma, w=32).pack(fill='x', pady=2, ipady=4)

        fb = tk.Frame(f, bg=BL); fb.pack(fill='x', pady=(14,0))
        _boton(fb, 'Cancelar', self.destroy, bg='#64748B').pack(side='left')
        _boton(fb, '🗑  Eliminar empresa', self._eliminar, bg=RO).pack(side='right')

        self._actualizar_info()
        _centrar(self, 440, 360)
        self.wait_window()

    def _actualizar_info(self):
        emp = self.v_emp.get()
        if not emp: return
        n = len(self.db.cargar_empresa(emp))
        self.lbl_info.config(
            text=f'⚠  Esta empresa tiene {n} empleado(s).\n\n'
                 f'Al eliminarla se borrará el archivo "{self.db.empresas.get(emp,"")}"\n'
                 f'y todos sus empleados desaparecerán de la base de datos.\n'
                 f'Esta acción NO se puede deshacer.')

    def _eliminar(self):
        emp = self.v_emp.get().strip()
        confirma = self.v_confirma.get().strip()
        if not emp:
            messagebox.showwarning('Selecciona empresa', 'Elige la empresa a eliminar.', parent=self)
            return
        if confirma != emp:
            messagebox.showwarning('Confirmación incorrecta',
                                    f'Escribe exactamente "{emp}" para confirmar.', parent=self)
            return
        try:
            self.db.eliminar_empresa(emp)
            messagebox.showinfo('Empresa eliminada', f'"{emp}" fue eliminada.', parent=self)
            self.ok = True; self.destroy()
        except ValueError as e:
            messagebox.showerror('Error', str(e), parent=self)


# ════════════════════════════════════════════════════════════════════════════
#  APLICACIÓN PRINCIPAL
# ════════════════════════════════════════════════════════════════════════════

class NominaApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('Procesador de Nómina')
        self.root.configure(bg=GF); self.root.resizable(True, True)
        self.db = EmpleadoDB(); self.ocupado = False; self.excel_generado = None
        self.biotime_var = tk.StringVar()
        self.fecha_ini_var = tk.StringVar(); self.fecha_fin_var = tk.StringVar()
        self._build(); _centrar(self.root, 820, 680)
        self._refrescar_tabla(); self._revisar_mapeo()
        self.root.mainloop()

    def _build(self):
        hdr = tk.Frame(self.root, bg=AZ, height=58); hdr.pack(fill='x'); hdr.pack_propagate(False)
        tk.Label(hdr, text='Procesador de Nómina', bg=AZ, fg=BL,
                 font=('Segoe UI', 16, 'bold')).pack(side='left', padx=20, pady=10)
        self.lbl_emps_hdr = tk.Label(hdr, text='', bg=AZ, fg='#93C5FD', font=('Segoe UI', 10))
        self.lbl_emps_hdr.pack(side='left')
        self._actualizar_header()

        style = ttk.Style()
        style.configure('TNotebook', background=GF, borderwidth=0)
        style.configure('TNotebook.Tab', font=('Segoe UI',10,'bold'), padding=[18,8],
                         background=GGD, foreground=GT)
        style.map('TNotebook.Tab', background=[('selected',BL)], foreground=[('selected',AZ)])

        nb = ttk.Notebook(self.root); nb.pack(fill='both', expand=True)
        self.tab_rep = tk.Frame(nb, bg=GF); self.tab_emp = tk.Frame(nb, bg=GF)
        nb.add(self.tab_rep, text='  📋  Generar Reporte  ')
        nb.add(self.tab_emp, text='  👥  Empleados  ')
        self._build_tab_reporte(); self._build_tab_empleados()

    def _actualizar_header(self):
        emps = self.db.nombres_empresas()
        self.lbl_emps_hdr.config(text='  ·  ' + '  ·  '.join(emps) if emps else '')

    # ─── TAB 1: GENERAR REPORTE ────────────────────────────────────────────

    def _build_tab_reporte(self):
        body = tk.Frame(self.tab_rep, bg=GF); body.pack(fill='both', expand=True, padx=24, pady=18)

        self._secc(body, '1', 'Archivo BioTime')
        fa = tk.Frame(body, bg=GF); fa.pack(fill='x', pady=(0,12))
        tk.Label(fa, textvariable=self.biotime_var, bg=BL, fg=NE, font=('Segoe UI',10),
                 anchor='w', relief='flat', bd=1, width=44, padx=8).pack(side='left', ipady=6)
        self._b(fa, '📂  Buscar', self._browse, AZM).pack(side='left', padx=(8,0))

        self._secc(body, '2', 'Período de nómina  (jueves a miércoles)')
        fp = tk.Frame(body, bg=GF); fp.pack(fill='x', pady=(0,12))
        tk.Label(fp, text='Del', bg=GF, fg=GT, font=('Segoe UI',10)).pack(side='left')
        tk.Entry(fp, textvariable=self.fecha_ini_var, font=('Segoe UI',11),
                 width=12, justify='center', relief='solid', bd=1, bg=GF
                 ).pack(side='left', padx=(6,0), ipady=4)
        tk.Label(fp, text='  al', bg=GF, fg=GT, font=('Segoe UI',10)).pack(side='left')
        tk.Entry(fp, textvariable=self.fecha_fin_var, font=('Segoe UI',11),
                 width=12, justify='center', relief='solid', bd=1, bg=GF
                 ).pack(side='left', padx=(6,0), ipady=4)
        tk.Label(fp, text='  DD/MM/AAAA', bg=GF, fg='#94A3B8', font=('Segoe UI',9)
                 ).pack(side='left', padx=6)

        self._secc(body, '3', 'Mapeo de empleados')
        fm = tk.Frame(body, bg=GF); fm.pack(fill='x', pady=(0,16))
        self.lbl_mapeo = tk.Label(fm, text='', bg=GF, font=('Segoe UI',10,'bold'), anchor='w')
        self.lbl_mapeo.pack(side='left', fill='x', expand=True)
        self.btn_mapeo = self._b(fm, 'Configurar', self._confirmar_mapeo, NA)
        self.btn_mapeo.pack(side='right')

        tk.Frame(body, bg=GB, height=1).pack(fill='x', pady=(0,14))
        self.btn_gen = tk.Button(body, text='▶   GENERAR REPORTE', command=self._generar,
                                  bg=VE, fg=BL, font=('Segoe UI',13,'bold'), relief='flat',
                                  padx=20, pady=11, cursor='hand2',
                                  activebackground='#15803D', activeforeground=BL)
        self.btn_gen.pack(fill='x')
        self.txt_log = scrolledtext.ScrolledText(body, height=7, font=('Consolas',9),
                                                  bg='#0F172A', fg='#94F57A', relief='flat',
                                                  bd=0, state='disabled', padx=10, pady=6)
        self.txt_log.pack(fill='x', pady=(12,0))
        self.btn_xl = tk.Button(body, text='📊  Abrir reporte en Excel',
                                 command=self._abrir_excel, bg=AZM, fg=BL,
                                 font=('Segoe UI',10,'bold'), relief='flat',
                                 padx=16, pady=8, cursor='hand2',
                                 activebackground='#1D4ED8', activeforeground=BL)

    # ─── TAB 2: EMPLEADOS ──────────────────────────────────────────────────

    def _build_tab_empleados(self):
        body = tk.Frame(self.tab_emp, bg=GF); body.pack(fill='both', expand=True, padx=18, pady=14)

        barra = tk.Frame(body, bg=GF); barra.pack(fill='x', pady=(0,8))
        tk.Label(barra, text='🔍', bg=GF, font=('Segoe UI',13)).pack(side='left')
        self.v_buscar = tk.StringVar()
        self.v_buscar.trace_add('write', lambda *_: self._filtrar())
        tk.Entry(barra, textvariable=self.v_buscar, font=('Segoe UI',11),
                 relief='solid', bd=1, bg=BL, width=28).pack(side='left', padx=(4,12), ipady=4)
        tk.Label(barra, text='Empresa:', bg=GF, fg=GT, font=('Segoe UI',10)).pack(side='left')
        self.v_filt_emp = tk.StringVar(value='Todas')
        self.cb_filt_emp = ttk.Combobox(barra, textvariable=self.v_filt_emp,
                                         state='readonly', width=14, font=('Segoe UI',10))
        self.cb_filt_emp.pack(side='left', padx=(4,8))
        self.cb_filt_emp.bind('<<ComboboxSelected>>', lambda *_: self._filtrar())
        tk.Label(barra, text='Tipo:', bg=GF, fg=GT, font=('Segoe UI',10)).pack(side='left')
        self.v_filt_tipo = tk.StringVar(value='Todos')
        cb_tipo = ttk.Combobox(barra, textvariable=self.v_filt_tipo,
                                values=['Todos'] + TIPOS, state='readonly', width=12,
                                font=('Segoe UI',10))
        cb_tipo.pack(side='left', padx=(4,0))
        cb_tipo.bind('<<ComboboxSelected>>', lambda *_: self._filtrar())
        self.lbl_count = tk.Label(barra, text='', bg=GF, fg='#64748B', font=('Segoe UI',9))
        self.lbl_count.pack(side='right')

        # Treeview
        ft = tk.Frame(body, bg=GF); ft.pack(fill='both', expand=True)
        style = ttk.Style()
        style.configure('N.Treeview', font=('Segoe UI',10), rowheight=26,
                         background=BL, fieldbackground=BL)
        style.configure('N.Treeview.Heading', font=('Segoe UI',9,'bold'))
        style.map('N.Treeview', background=[('selected','#BFDBFE')])

        cols = ('id','nombre','tipo','empresa','salario','sbc')
        self.tree = ttk.Treeview(ft, columns=cols, show='headings',
                                  style='N.Treeview', selectmode='browse')
        for col,txt,w,anch in [
            ('id','ID',85,'center'),('nombre','Nombre',270,'w'),
            ('tipo','Tipo',100,'center'),('empresa','Empresa',105,'center'),
            ('salario','Salario D.',110,'center'),('sbc','SBC',110,'center')]:
            self.tree.heading(col, text=txt, command=lambda c=col: self._ordenar(c))
            self.tree.column(col, width=w, anchor=anch)

        self.tree.tag_configure('perm',  background='#F0FDF4')   # verde muy claro = permanente
        self.tree.tag_configure('evnt',  background='#FEF9C3')   # amarillo = eventual
        self.tree.tag_configure('sin',   background=BL)           # sin tipo
        sb = ttk.Scrollbar(ft, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side='left', fill='both', expand=True); sb.pack(side='right', fill='y')
        self.tree.bind('<Double-1>', lambda e: self._editar())

        sep = tk.Frame(body, bg=GB, height=1); sep.pack(fill='x', pady=(10,8))
        acc = tk.Frame(body, bg=GF); acc.pack(fill='x')
        self._b(acc, '✚  Añadir', self._añadir, VE).pack(side='left', padx=(0,6))
        self._b(acc, '✎  Editar', self._editar, AZM).pack(side='left', padx=(0,6))
        self._b(acc, '↔  Mover', self._mover, MO).pack(side='left', padx=(0,6))
        self._b(acc, '✗  Dar de baja', self._baja, RO).pack(side='left')
        self._b(acc, '➕  Añadir empresa', self._nueva_empresa, NA).pack(side='right')
        self._b(acc, '🗑  Eliminar empresa', self._eliminar_empresa, RO).pack(side='right', padx=(0,6))

        tk.Label(body, text='Verde claro = Permanente  ·  Amarillo = Eventual  ·  Doble clic para editar',
                 bg=GF, fg='#94A3B8', font=('Segoe UI',8)).pack(anchor='w', pady=(4,0))

    # ─── Helpers ──────────────────────────────────────────────────────────

    def _secc(self, p, num, texto):
        f = tk.Frame(p, bg=GF); f.pack(fill='x', pady=(0,6))
        tk.Label(f, text=f' {num} ', bg=AZ, fg=BL, font=('Segoe UI',9,'bold'), padx=5
                 ).pack(side='left')
        tk.Label(f, text=f'  {texto}', bg=GF, fg=AZ, font=('Segoe UI',10,'bold')
                 ).pack(side='left')

    def _b(self, p, t, cmd, bg, **kw):
        return tk.Button(p, text=t, command=cmd, bg=bg, fg=BL,
                         font=('Segoe UI',9,'bold'), relief='flat',
                         padx=10, pady=6, cursor='hand2',
                         activebackground=bg, activeforeground=BL, **kw)

    # ─── Tabla ────────────────────────────────────────────────────────────

    def _refrescar_tabla(self):
        self.db._cargar_empresas()
        self._todos = self.db.cargar_todos()
        self.cb_filt_emp['values'] = ['Todas'] + self.db.nombres_empresas()
        self._filtrar(); self._actualizar_header()

    def _filtrar(self):
        buscar   = self.v_buscar.get().strip().upper()
        empresa  = self.v_filt_emp.get()
        tipo     = self.v_filt_tipo.get()
        df = self._todos.copy()
        if empresa and empresa != 'Todas': df = df[df['Empresa'] == empresa]
        if tipo and tipo != 'Todos':       df = df[df['Tipo'] == tipo]
        if buscar:
            mask = (df['Nombre'].str.upper().str.contains(buscar, na=False) |
                    df['ID'].str.upper().str.contains(buscar, na=False))
            df = df[mask]
        self.tree.delete(*self.tree.get_children())
        for _, r in df.iterrows():
            tp = str(r.get('Tipo','')).strip()
            tag = 'perm' if tp == 'Permanente' else ('evnt' if tp == 'Eventual' else 'sin')
            self.tree.insert('', 'end', iid=f"{r['Empresa']}|{r['ID']}",
                              values=(r['ID'], r['Nombre'], tp,
                                      r['Empresa'], r['Salario Diario'], r['SBC']),
                              tags=(tag,))
        self.lbl_count.config(text=f'{len(df)} de {len(self._todos)} empleados')

    def _ordenar(self, col):
        items = [(self.tree.set(k, col), k) for k in self.tree.get_children('')]
        items.sort(key=lambda x: x[0].lower())
        for idx, (_, k) in enumerate(items): self.tree.move(k, '', idx)

    def _emp_sel(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo('Selecciona un empleado', 'Haz clic en un empleado primero.')
            return None
        # ID y Empresa se leen del iid (texto original, sin pasar por Treeview values)
        # porque Tkinter puede convertir IDs numéricos con ceros a la izquierda
        # (ej. "00069") perdiendo los ceros al leerlos de vuelta desde 'values'.
        iid = sel[0]
        empresa_iid, id_iid = iid.split('|', 1)
        v = self.tree.item(sel[0])['values']
        def _s(x): return '' if x is None else str(x)
        return {'ID': id_iid, 'Nombre': _s(v[1]), 'Tipo': _s(v[2]),
                'Empresa': empresa_iid, 'Salario Diario': _s(v[4]), 'SBC': _s(v[5])}

    # ─── Acciones empleados ────────────────────────────────────────────────

    def _añadir(self):
        dlg = DlgEmpleado(self.root, self.db, modo='añadir')
        if dlg.ok: self._refrescar_tabla()

    def _editar(self):
        emp = self._emp_sel()
        if not emp: return
        dlg = DlgEmpleado(self.root, self.db, modo='editar', empleado=emp)
        if dlg.ok: self._refrescar_tabla()

    def _mover(self):
        emp = self._emp_sel()
        if not emp: return
        if len(self.db.nombres_empresas()) < 2:
            messagebox.showinfo('Sin destino', 'Necesitas al menos 2 empresas para mover.'); return
        dlg = DlgMover(self.root, self.db, emp)
        if dlg.ok: self._refrescar_tabla()

    def _baja(self):
        emp = self._emp_sel()
        if not emp: return
        tipo_txt = f" ({emp.get('Tipo','')})" if emp.get('Tipo') else ''
        if messagebox.askyesno('Confirmar baja',
            f'¿Dar de baja a:\n\n{emp["Nombre"]}{tipo_txt}\n'
            f'ID: {emp["ID"]}  —  {emp["Empresa"]}\n\n'
            f'Esta acción no se puede deshacer.', icon='warning'):
            self.db.dar_de_baja(emp['ID'], emp['Empresa'])
            self._refrescar_tabla()

    def _nueva_empresa(self):
        dlg = DlgEmpresa(self.root, self.db)
        if dlg.ok: self._refrescar_tabla()

    def _eliminar_empresa(self):
        if not self.db.nombres_empresas():
            messagebox.showinfo('Sin empresas', 'No hay empresas para eliminar.')
            return
        dlg = DlgEliminarEmpresa(self.root, self.db)
        if dlg.ok: self._refrescar_tabla()

    # ─── Reporte (Tab 1) ───────────────────────────────────────────────────

    def _browse(self):
        ruta = filedialog.askopenfilename(title='Seleccionar BioTime',
                                           filetypes=[('CSV','*.csv'),('Todos','*.*')],
                                           initialdir=SCRIPT_DIR)
        if ruta: self.biotime_var.set(ruta); self._log(f'✓  {os.path.basename(ruta)}')

    def _revisar_mapeo(self):
        mapeo = os.path.join(SCRIPT_DIR, 'mapeo_empleados.csv')
        if os.path.exists(mapeo):
            try:
                df  = pd.read_csv(mapeo, dtype=str); tot = len(df)
                rev = len(df[df['Revisar'].isin(['SI','MANUAL'])])
                self.lbl_mapeo.config(text=f'✓  Configurado — {tot} empleados', fg=VE)
                self.btn_mapeo.config(text='Reconfigurar', bg='#64748B')
                if rev: self._log(f'⚠  {rev} empleado(s) en el mapeo requieren revisión.')
            except Exception:
                self.lbl_mapeo.config(text='⚠  Error leyendo el mapeo', fg=RO)
        else:
            self.lbl_mapeo.config(
                text='✗  Sin configurar — necesario antes de generar reportes', fg=RO)
            self.btn_mapeo.config(text='Configurar ahora', bg=NA)

    def _confirmar_mapeo(self):
        if not self.biotime_var.get():
            messagebox.showwarning('Archivo faltante', 'Selecciona el archivo BioTime primero.'); return
        mapeo = os.path.join(SCRIPT_DIR, 'mapeo_empleados.csv')
        if os.path.exists(mapeo):
            if not messagebox.askyesno('Reconfigurar',
                '¿Reemplazar el mapeo actual?\nHazlo solo si cambiaron los empleados.'): return
        self._correr(self._tarea_mapeo)

    def _generar(self):
        if not self.biotime_var.get():
            messagebox.showwarning('Archivo faltante', 'Selecciona el archivo BioTime primero.'); return
        if not os.path.exists(os.path.join(SCRIPT_DIR, 'mapeo_empleados.csv')):
            messagebox.showwarning('Mapeo faltante', 'Configura el mapeo primero (Paso 3).'); return
        ini = self.fecha_ini_var.get().strip(); fin = self.fecha_fin_var.get().strip()
        if not ini or not fin:
            messagebox.showwarning('Fechas faltantes', 'Ingresa las fechas del período (Paso 2).'); return
        try:
            from datetime import datetime as dt
            dt.strptime(ini,'%d/%m/%Y'); dt.strptime(fin,'%d/%m/%Y')
        except ValueError:
            messagebox.showerror('Fecha incorrecta', 'Usa DD/MM/AAAA — ej: 11/06/2026'); return
        self._correr(lambda: self._tarea_reporte(ini, fin))

    def _abrir_excel(self):
        if self.excel_generado and os.path.exists(self.excel_generado):
            os.startfile(self.excel_generado)

    # ─── Tareas hilo ───────────────────────────────────────────────────────

    def _tarea_mapeo(self):
        try:
            from nomina import cargar_contpaq, cargar_biotime, generar_mapeo
            buf = io.StringIO()
            self._log('\n  Cargando empleados...')
            with contextlib.redirect_stdout(buf): df_cp = cargar_contpaq()
            self._log(f'  {len(df_cp)} empleados en {df_cp["Empresa"].nunique()} empresa(s)')
            self._log('\n  Leyendo BioTime...')
            with contextlib.redirect_stdout(buf): df_bt = cargar_biotime(self.biotime_var.get())
            self._log(f'  {df_bt["ID_BT"].nunique()} empleados  ·  {len(df_bt)} registros')
            self._log('\n  Buscando correspondencias...')
            with contextlib.redirect_stdout(buf): df_mapeo = generar_mapeo(df_bt, df_cp)
            con = len(df_mapeo[~df_mapeo['CONTPAQ_ID'].str.startswith('⚠', na=False)])
            sin = len(df_mapeo) - con
            self._log(f'\n  ✓ Encontrados: {con}   ⚠ Sin match: {sin}')
            self.root.after(0, self._revisar_mapeo)
            if sin:
                self._log('\n  Abriendo mapeo_empleados.csv para revisión...')
                self.root.after(500, lambda: os.startfile(os.path.join(SCRIPT_DIR,'mapeo_empleados.csv')))
                self.root.after(0, lambda: messagebox.showinfo('Revisar mapeo',
                    f'{sin} empleado(s) sin match.\nRevisa y corrige las filas rojas en mapeo_empleados.csv.'))
            else:
                self._log('\n  🎉 Todos identificados correctamente.')
        except Exception as e:
            self._log(f'\n  ❌  Error: {e}')
            import traceback; self._log(traceback.format_exc())

    def _tarea_reporte(self, ini, fin):
        try:
            import pandas as pd
            from datetime import datetime as dt
            from nomina import (cargar_contpaq, cargar_biotime, procesar,
                                generar_excel, _añadir_sbc_si_falta, _añadir_tipo_si_falta)
            buf = io.StringIO()
            self._log('\n  Cargando datos...')
            with contextlib.redirect_stdout(buf):
                df_cp  = cargar_contpaq()
                df_bt  = cargar_biotime(self.biotime_var.get())
                df_map = pd.read_csv(os.path.join(SCRIPT_DIR,'mapeo_empleados.csv'), dtype=str)
                df_map['CONTPAQ_Salario'] = pd.to_numeric(df_map['CONTPAQ_Salario'], errors='coerce').fillna(0)
                df_map = _añadir_sbc_si_falta(df_map)
                df_map = _añadir_tipo_si_falta(df_map)
            self._log(f'  {df_bt["ID_BT"].nunique()} empleados en BioTime')
            f_ini = dt.strptime(ini,'%d/%m/%Y'); f_fin = dt.strptime(fin,'%d/%m/%Y')
            self._log(f'  Período: {ini} → {fin}')
            self._log('\n  Calculando asistencias...')
            with contextlib.redirect_stdout(buf):
                resultado, dias = procesar(df_bt, df_map, f_ini, f_fin)
            faltas = sum(e['total_faltas'] for e in resultado)
            ded    = sum(e['deduccion']    for e in resultado)
            self._log(f'  {len(resultado)} empleados · {faltas} falta(s) · ${ded:,.2f} deducción')
            self._log('\n  Generando Excel...')
            nominas_dir = os.path.join(SCRIPT_DIR, 'nominas')
            os.makedirs(nominas_dir, exist_ok=True)
            nombre = f"Nominas-{f_ini:%d}-{f_fin:%d}-{f_ini:%m}-{f_ini:%Y}.xlsx"
            ruta   = os.path.join(nominas_dir, nombre)
            with contextlib.redirect_stdout(buf):
                generar_excel(resultado, dias, f_ini, f_fin, ruta)
            self.excel_generado = ruta
            self._log(f'\n  ✅  Reporte listo: nominas/{nombre}')
            self.root.after(0, self._mostrar_btn_xl)
        except Exception as e:
            self._log(f'\n  ❌  Error: {e}')
            import traceback; self._log(traceback.format_exc())

    def _mostrar_btn_xl(self):
        self.btn_xl.pack(pady=(10,0))

    def _log(self, msg):
        def _u():
            self.txt_log.config(state='normal')
            self.txt_log.insert('end', msg+'\n')
            self.txt_log.see('end')
            self.txt_log.config(state='disabled')
        self.root.after(0, _u)

    def _correr(self, func):
        if self.ocupado:
            messagebox.showinfo('Espera', 'Ya hay un proceso en curso.'); return
        self.ocupado = True
        self.btn_gen.config(state='disabled', text='⏳  Procesando...', bg='#94A3B8')
        self.btn_mapeo.config(state='disabled')
        def hilo():
            try: func()
            finally:
                self.ocupado = False
                self.root.after(0, self._restaurar)
        threading.Thread(target=hilo, daemon=True).start()

    def _restaurar(self):
        self.btn_gen.config(state='normal', text='▶   GENERAR REPORTE', bg=VE)
        self.btn_mapeo.config(state='normal')


if __name__ == '__main__':
    NominaApp()
