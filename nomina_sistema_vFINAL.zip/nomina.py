#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════╗
║   PROCESADOR DE NÓMINA  —  BioTime → CONTPAQi           ║
║   Empresas: La Cima / RC                                ║
╚══════════════════════════════════════════════════════════╝

USO:
  Primera vez (genera el mapeo de empleados):
    python nomina.py biotime.csv --setup

  Cada quincena / semana:
    python nomina.py biotime.csv --inicio 01/06/2026 --fin 15/06/2026

  Sin fechas usa todo el rango del archivo:
    python nomina.py biotime.csv
"""

import pandas as pd
from datetime import datetime, timedelta
import unicodedata
import re
import os
import sys
import argparse

try:
    from openpyxl import Workbook
    from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    print("Instalando openpyxl...")
    os.system(f'"{sys.executable}" -m pip install openpyxl')
    from openpyxl import Workbook
    from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

# ─── Rutas ────────────────────────────────────────────────────────────────────
SCRIPT_DIR     = os.path.dirname(os.path.abspath(__file__))
# Cuando corre como .exe compilado con PyInstaller, usar la carpeta del .exe
if getattr(sys, 'frozen', False):
    SCRIPT_DIR = os.path.dirname(sys.executable)
ARCHIVO_LACIMA = os.path.join(SCRIPT_DIR, "lacima.csv")
ARCHIVO_RC     = os.path.join(SCRIPT_DIR, "rc.csv")
ARCHIVO_MAPEO  = os.path.join(SCRIPT_DIR, "mapeo_empleados.csv")
THRESHOLD      = 0.75
HORAS_JORNADA  = 8      # ← Horas a partir de las cuales empiezan a contar horas extras
HORAS_PAGO     = 8      # ← Horas que equivalen a un día completo de sueldo
                       #    (si trabaja >= 8h se paga día completo; si trabaja menos,
                       #     se paga SalarioDiario/8 * horas trabajadas ese día)
EXTRAS_DOBLES_MAX = 9  # ← Las primeras 9 HE de la semana se pagan dobles; de la 10 en
                       #    adelante, triples
UMA            = 113.14  # ← Valor diario de la UMA (actualizar cuando el SAT lo cambie)
UMA_3          = round(UMA * 3, 2)  # 3 veces la UMA, usado en el cálculo de IMSS

DIAS_ES = {0:'Lun', 1:'Mar', 2:'Mié', 3:'Jue', 4:'Vie', 5:'Sáb', 6:'Dom'}

# ═══════════════════════════════════════════════════════════════════════════════
#  NOMBRES
# ═══════════════════════════════════════════════════════════════════════════════

def normalizar(texto):
    if not isinstance(texto, str):
        return ""
    t = texto.upper().strip()
    t = unicodedata.normalize('NFKD', t)
    t = ''.join(c for c in t if not unicodedata.combining(c))
    t = re.sub(r'[^A-Z\s]', '', t)
    return re.sub(r'\s+', ' ', t).strip()

def tokens(n):
    s = normalizar(n)
    return set(s.split()) if s else set()

def jaccard(a, b):
    t1, t2 = tokens(a), tokens(b)
    if not t1 or not t2:
        return 0.0
    return len(t1 & t2) / len(t1 | t2)

def mejor_match(nombre_bt, df_cp):
    mejor_s, mejor_f = 0.0, None
    for _, f in df_cp.iterrows():
        s = jaccard(nombre_bt, f['Nombre'])
        if s > mejor_s:
            mejor_s, mejor_f = s, f
    return (mejor_f, mejor_s) if mejor_s >= THRESHOLD else (None, mejor_s)

# ═══════════════════════════════════════════════════════════════════════════════
#  CARGA DE DATOS
# ═══════════════════════════════════════════════════════════════════════════════

def cargar_contpaq():
    """Carga empleados de todas las empresas registradas en empresas.json."""
    import json as _json
    ejson = os.path.join(SCRIPT_DIR, 'empresas.json')
    if os.path.exists(ejson):
        with open(ejson, 'r', encoding='utf-8') as f:
            empresas = _json.load(f)
    else:
        empresas = {'La Cima': 'lacima.csv', 'RC': 'rc.csv'}

    dfs = []
    for empresa, archivo in empresas.items():
        ruta = os.path.join(SCRIPT_DIR, archivo)
        if not os.path.exists(ruta):
            print(f"  ⚠  No encontrado: {archivo}")
            continue
        df = pd.read_csv(ruta, sep='\t', dtype=str)
        df.columns = [c.strip() for c in df.columns]
        df['Empresa'] = empresa
        df['Nombre'] = df['Nombre'].str.strip()
        df['Salario Diario'] = pd.to_numeric(
            df['Salario Diario'].str.replace(',', '.', regex=False), errors='coerce'
        ).fillna(0)
        if 'SBC' in df.columns:
            df['SBC'] = pd.to_numeric(
                df['SBC'].str.replace(',', '.', regex=False), errors='coerce'
            ).fillna(0)
        else:
            df['SBC'] = 0
        dfs.append(df)
    if not dfs:
        raise FileNotFoundError("No se encontraron archivos de empleados.")
    return pd.concat(dfs, ignore_index=True)


def _añadir_sbc_si_falta(df_mapeo):
    """
    Si un mapeo viejo no tiene la columna CONTPAQ_SBC, la rellena cruzando
    el CONTPAQ_ID + empresa con los archivos lacima.csv / rc.csv.
    """
    if 'CONTPAQ_SBC' in df_mapeo.columns:
        df_mapeo['CONTPAQ_SBC'] = pd.to_numeric(
            df_mapeo['CONTPAQ_SBC'], errors='coerce').fillna(0)
        return df_mapeo

    try:
        df_cp = cargar_contpaq()
        # Construir índice (Empresa, ID) → SBC
        sbc_idx = {}
        for _, r in df_cp.iterrows():
            sbc_idx[(str(r['Empresa']).strip(), str(r['ID']).strip())] = r['SBC']
        def buscar(row):
            return sbc_idx.get(
                (str(row.get('CONTPAQ_Empresa','')).strip(),
                 str(row.get('CONTPAQ_ID','')).strip()), 0)
        df_mapeo['CONTPAQ_SBC'] = df_mapeo.apply(buscar, axis=1)
    except Exception:
        df_mapeo['CONTPAQ_SBC'] = 0

    df_mapeo['CONTPAQ_SBC'] = pd.to_numeric(
        df_mapeo['CONTPAQ_SBC'], errors='coerce').fillna(0)
    return df_mapeo


def _añadir_tipo_si_falta(df_mapeo):
    """
    Si el mapeo no tiene CONTPAQ_Tipo, lo rellena cruzando con los CSVs de empleados.
    Si el empleado no tiene Tipo asignado, queda vacío (se tratará como Permanente).
    """
    if 'CONTPAQ_Tipo' in df_mapeo.columns:
        return df_mapeo
    try:
        df_cp = cargar_contpaq()
        tipo_idx = {}
        for _, r in df_cp.iterrows():
            if 'Tipo' in r.index:
                tipo_idx[(str(r['Empresa']).strip(), str(r['ID']).strip())] = \
                    str(r.get('Tipo', '')).strip()
        def _buscar_tipo(row):
            return tipo_idx.get(
                (str(row.get('CONTPAQ_Empresa','')).strip(),
                 str(row.get('CONTPAQ_ID','')).strip()), '')
        df_mapeo['CONTPAQ_Tipo'] = df_mapeo.apply(_buscar_tipo, axis=1)
    except Exception:
        df_mapeo['CONTPAQ_Tipo'] = ''
    return df_mapeo


def cargar_biotime(ruta):
    encodings  = ['utf-8-sig', 'utf-8', 'latin-1', 'cp1252']
    separadores = ['\t', ',', ';', '|']
    df = None
    for enc in encodings:
        for sep in separadores:
            try:
                tmp = pd.read_csv(ruta, sep=sep, dtype=str, encoding=enc, nrows=3)
                if len(tmp.columns) >= 6:
                    df = pd.read_csv(ruta, sep=sep, dtype=str, encoding=enc)
                    print(f"  → Formato: sep={'TAB' if sep==chr(9) else repr(sep)}, enc={enc}")
                    break
            except Exception:
                continue
        if df is not None:
            break

    if df is None:
        raise ValueError("No se pudo leer el archivo BioTime.")

    df.columns = [c.strip() for c in df.columns]
    print(f"  → Columnas: {list(df.columns)}")

    nombre_col   = next((c for c in df.columns if 'nombre' in c.lower() and 'empleado' not in c.lower()), None)
    apellido_col = next((c for c in df.columns if 'apellido' in c.lower()), None)
    id_col       = next((c for c in df.columns if 'id' in c.lower() and 'empleado' in c.lower()), None)
    fecha_col    = next((c for c in df.columns if 'fecha' in c.lower()), None)
    hora_col     = next((c for c in df.columns if 'hora' in c.lower() or 'tiempo' in c.lower()), None)

    if not all([nombre_col, apellido_col, id_col, fecha_col]):
        if len(df.columns) >= 8:
            df.columns = (['ID_BT','Nombre_BT','Apellido_BT','Departamento',
                           'Cargo','Fecha','Checadas','Hora'] + list(df.columns[8:]))
            hora_col = 'Hora'
        else:
            raise ValueError(f"Formato inesperado. Columnas: {list(df.columns)}")
    else:
        df = df.rename(columns={
            id_col:       'ID_BT',
            nombre_col:   'Nombre_BT',
            apellido_col: 'Apellido_BT',
            fecha_col:    'Fecha',
        })
        if hora_col and hora_col not in ['ID_BT','Nombre_BT','Apellido_BT','Fecha']:
            df = df.rename(columns={hora_col: 'Hora'})
        elif 'Hora' not in df.columns:
            df['Hora'] = ''

    df['Nombre_completo'] = (
        df['Nombre_BT'].fillna('').str.strip() + ' ' +
        df['Apellido_BT'].fillna('').str.strip()
    ).str.strip()

    df['Fecha'] = pd.to_datetime(df['Fecha'], format='%d/%m/%Y', errors='coerce')
    df = df.dropna(subset=['Fecha'])
    df['ID_BT'] = df['ID_BT'].str.strip()
    return df

# ═══════════════════════════════════════════════════════════════════════════════
#  TIEMPOS DE ENTRADA / SALIDA
# ═══════════════════════════════════════════════════════════════════════════════

def parsear_tiempos(hora_str):
    """
    Dado "06:30:15,06:30:18,15:00:22,15:00:25"
    agrupa duplicados (< 10 min) y devuelve (entrada, salida) como "HH:MM".
    Si solo hay un grupo → salida = None.
    """
    if pd.isna(hora_str) or not str(hora_str).strip():
        return None, None

    mins = []
    for t in str(hora_str).split(','):
        partes = t.strip().split(':')
        try:
            mins.append(int(partes[0]) * 60 + int(partes[1]))
        except (ValueError, IndexError):
            continue

    if not mins:
        return None, None

    mins.sort()

    # Agrupar tiempos que están a menos de 10 minutos entre sí
    grupos = [[mins[0]]]
    for m in mins[1:]:
        if m - grupos[-1][-1] < 10:
            grupos[-1].append(m)
        else:
            grupos.append([m])

    representantes = [g[0] for g in grupos]

    def fmt(m):
        return f"{m//60:02d}:{m%60:02d}"

    if len(representantes) == 1:
        return fmt(representantes[0]), None

    t_min = representantes[0]
    t_max = representantes[-1]

    diff_directa  = t_max - t_min           # minutos si min=entrada, max=salida
    diff_nocturna = (t_min + 24 * 60) - t_max  # minutos si max=entrada, min=salida día siguiente

    UMBRAL    = 13 * 60  # si supera 13h en interpretación directa → sospechar turno nocturno
    RANGO_MIN =  4 * 60  # turno mínimo razonable (4h)

    if diff_directa > UMBRAL and RANGO_MIN <= diff_nocturna < diff_directa:
        # Turno nocturno detectado: entrada=tiempo mayor, salida=tiempo menor (día siguiente)
        # calcular_horas_y_extras detectará salida < entrada y sumará 24h automáticamente
        return fmt(t_max), fmt(t_min)
    else:
        return fmt(t_min), fmt(t_max)


def _str_a_min(hora_str):
    """'HH:MM' → minutos desde medianoche. Devuelve None si falla."""
    try:
        h, m = str(hora_str).split(':')[:2]
        return int(h) * 60 + int(m)
    except Exception:
        return None


def calcular_horas_y_extras(entrada_str, salida_str, jornada_horas=None):
    """
    Calcula horas trabajadas y horas extras del día.

    Regla de horas extras:
      - Se necesita trabajar MÁS de 55 min extra para que cuente algo.
      - Los minutos del extra se redondean con umbral de 55:
          0 – 54 min → no cuenta
         55 – 1h54m  → 1 hora extra
        1h55 – 2h54m → 2 horas extras  … etc.

    Devuelve:
      horas_str  : "8h 30m"  o None si no hay datos
      extras_int : número entero de horas extras (0, 1, 2…)
      minutos    : minutos trabajados (int) o 0
    """
    if not entrada_str or not salida_str or salida_str == '(sin salida)':
        return None, 0, 0

    e = _str_a_min(entrada_str)
    s = _str_a_min(salida_str)
    if e is None or s is None:
        return None, 0, 0

    # Turno nocturno: si la salida es "antes" de la entrada, es el día siguiente
    if s < e:
        s += 24 * 60

    trabajados = s - e
    if trabajados <= 0:
        return None, 0, 0

    horas_str = f"{trabajados // 60}h {trabajados % 60:02d}m"

    # Horas extras
    jornada = int(jornada_horas or HORAS_JORNADA)
    extra_min = max(0, trabajados - jornada * 60)

    if extra_min <= 55:        # 55 min o menos → no cuenta
        extras = 0
    else:
        horas_e = extra_min // 60
        resto_e = extra_min % 60
        extras  = horas_e + (1 if resto_e >= 55 else 0)

    return horas_str, extras, trabajados


# ═══════════════════════════════════════════════════════════════════════════════
#  MAPEO (primera vez)
# ═══════════════════════════════════════════════════════════════════════════════

def generar_mapeo(df_bt, df_cp):
    print("\n  Buscando correspondencias de nombres...")
    unicos = df_bt.groupby('ID_BT').first().reset_index()[['ID_BT','Nombre_completo','Departamento']]

    filas = []
    for _, emp in unicos.iterrows():
        match, score = mejor_match(emp['Nombre_completo'], df_cp)
        if match is not None:
            filas.append({
                'BioTime_ID':      emp['ID_BT'],
                'BioTime_Nombre':  emp['Nombre_completo'],
                'BioTime_Depto':   emp.get('Departamento',''),
                'CONTPAQ_ID':      match['ID'],
                'CONTPAQ_Nombre':  match['Nombre'],
                'CONTPAQ_Empresa': match['Empresa'],
                'CONTPAQ_Salario': match['Salario Diario'],
                'CONTPAQ_SBC':     match.get('SBC', 0),
                'CONTPAQ_Tipo':    match['Tipo'] if 'Tipo' in match.index and pd.notna(match.get('Tipo','')) else '',
                'Score':           round(score, 3),
                'Revisar':         'SI' if score < 0.90 else 'NO'
            })
        else:
            filas.append({
                'BioTime_ID':      emp['ID_BT'],
                'BioTime_Nombre':  emp['Nombre_completo'],
                'BioTime_Depto':   emp.get('Departamento',''),
                'CONTPAQ_ID':      '⚠ SIN MATCH',
                'CONTPAQ_Nombre':  '',
                'CONTPAQ_Empresa': '',
                'CONTPAQ_Salario': 0,
                'CONTPAQ_SBC':     0,
                'CONTPAQ_Tipo':    '',
                'Score':           round(score, 3),
                'Revisar':         'MANUAL'
            })

    df_mapeo = pd.DataFrame(filas).sort_values(['Revisar','Score'], ascending=[False,True])
    df_mapeo.to_csv(ARCHIVO_MAPEO, index=False, encoding='utf-8-sig')

    con = sum(1 for f in filas if f['CONTPAQ_ID'] != '⚠ SIN MATCH')
    sin = len(filas) - con
    rev = sum(1 for f in filas if f['Revisar'] == 'SI')
    print(f"  ✓ Match automático: {con}   ⚠ Sin match: {sin}   📋 Revisar: {rev}")
    print(f"\n  → Abre mapeo_empleados.csv, corrige las filas en rojo y vuelve a correr sin --setup.\n")
    return df_mapeo


# ═══════════════════════════════════════════════════════════════════════════════
#  PROCESAMIENTO DE ASISTENCIA
# ═══════════════════════════════════════════════════════════════════════════════

def procesar(df_bt, df_mapeo, f_ini, f_fin, jornada_horas=None):
    """
    Para cada empleado y cada día Lun-Sáb del periodo:
    - Si tiene registro en BioTime → entrada, salida, horas trabajadas, horas extras
    - Si no tiene registro         → FALTA
    - Domingo                      → DOM (no se cuenta)
    Retorna lista de dicts con toda la info por empleado.
    """
    print(f"\n  Procesando {f_ini:%d/%m/%Y} → {f_fin:%d/%m/%Y}  ...")

    dias = []
    d = f_ini
    while d <= f_fin:
        dias.append(d)
        d += timedelta(days=1)

    dias_trabajo = [d for d in dias if d.weekday() != 6]

    df_p = df_bt[(df_bt['Fecha'] >= f_ini) & (df_bt['Fecha'] <= f_fin)].copy()

    idx = {}
    for _, row in df_p.iterrows():
        key = (str(row['ID_BT']).strip(), row['Fecha'].date())
        idx[key] = row

    ids_en_periodo = set(df_p['ID_BT'].unique())

    df_val = df_mapeo[~df_mapeo['CONTPAQ_ID'].str.startswith('⚠')].copy()

    resultado = []
    for _, emp in df_val.iterrows():
        bt_id   = str(emp['BioTime_ID']).strip()
        salario = float(emp['CONTPAQ_Salario'])
        sbc     = float(emp.get('CONTPAQ_SBC', 0) or 0)
        tipo    = str(emp.get('CONTPAQ_Tipo', '') or '').strip()

        dias_info     = {}
        faltas        = []
        total_faltas  = 0
        total_extras  = 0    # horas extras de la semana
        dias_trab     = 0    # total de días que asistió (cualquier día, cualquier hora)
        domingos_trab = 0    # domingos trabajados (para prima dominical)
        sueldo_dias   = 0.0  # acumulado del pago por días trabajados (proporcional)

        for dia in dias:
            es_domingo = (dia.weekday() == 6)
            reg = idx.get((bt_id, dia.date()))

            if reg is not None:
                # Asistió este día
                hora_str        = reg.get('Hora', '')
                entrada, salida = parsear_tiempos(hora_str)
                salida_display  = salida or '(sin salida)'
                horas, extras, minutos = calcular_horas_y_extras(
                    entrada, salida, jornada_horas)
                total_extras += extras
                dias_trab    += 1

                if es_domingo:
                    domingos_trab += 1

                # Pago del día (proporcional si trabajó menos de HORAS_PAGO horas)
                if minutos and minutos > 0:
                    horas_dia = minutos / 60.0
                    if horas_dia >= HORAS_PAGO:
                        sueldo_dias += salario
                    else:
                        sueldo_dias += (salario / HORAS_PAGO) * horas_dia
                else:
                    # Registró checada pero sin par entrada/salida → día completo
                    sueldo_dias += salario

                dias_info[dia] = {
                    'estado':  'DOM_OK' if es_domingo else 'OK',
                    'entrada': entrada or '?',
                    'salida':  salida_display,
                    'horas':   horas,
                    'extras':  extras
                }
            else:
                # No asistió
                if es_domingo:
                    dias_info[dia] = {'estado':'DOM','entrada':'','salida':'',
                                      'horas':None,'extras':0}
                else:
                    dias_info[dia] = {'estado':'FALTA','entrada':'','salida':'',
                                      'horas':None,'extras':0}
                    faltas.append(dia)
                    total_faltas += 1

        # ── Estado descriptivo ────────────────────────────────────────────────
        if total_faltas == 0:
            estado_txt = '✓ Fue todos los días'
        else:
            fechas_str = ', '.join(
                f"{DIAS_ES[d.weekday()]} {d.day:02d}/{d.month:02d}" for d in faltas
            )
            estado_txt = f'✗ Faltó {total_faltas} día(s): {fechas_str}'

        # ── Días laborables del periodo (Lun-Sáb) para el séptimo día ─────────
        dias_lun_sab = [d for d in dias if d.weekday() != 6]
        dias_trab_lunsab = sum(
            1 for d in dias_lun_sab
            if dias_info[d]['estado'] in ('OK', 'DOM_OK')
        )

        # ── Cálculos de percepciones ──────────────────────────────────────────
        sueldo_dias_trab = round(sueldo_dias, 2)

        # Séptimo día = SalarioDiario/6 * días trabajados (Lun-Sáb)
        septimo_dia = round((salario / 6.0) * dias_trab_lunsab, 2)

        # Prima dominical = SalarioDiario * 0.25 por cada domingo trabajado
        prima_dominical = round(salario * 0.25 * domingos_trab, 2)

        # Importe horas extras: primeras 9 dobles, de la 10 en adelante triples
        valor_hora = salario / 8.0
        he_dobles  = min(total_extras, EXTRAS_DOBLES_MAX)
        he_triples = max(0, total_extras - EXTRAS_DOBLES_MAX)
        importe_he = round(valor_hora * 2 * he_dobles + valor_hora * 3 * he_triples, 2)

        resultado.append({
            'empresa':          emp['CONTPAQ_Empresa'],
            'id':               emp['CONTPAQ_ID'],
            'nombre':           emp['CONTPAQ_Nombre'],
            'nombre_bt':        emp['BioTime_Nombre'],
            'salario':          salario,
            'sbc':              sbc,
            'tipo':             tipo,
            'estado':           estado_txt,
            'total_faltas':     total_faltas,
            'total_extras':     total_extras,
            'dias_trabajados':  dias_trab,
            'deduccion':        round(total_faltas * salario, 2),
            # Columnas de percepciones calculadas
            'sueldo_dias_trab': sueldo_dias_trab,
            'septimo_dia':      septimo_dia,
            'prima_dominical':  prima_dominical,
            'importe_he':       importe_he,
            'dias_info':        dias_info,
            'dias':             dias
        })

    return resultado, dias


# ═══════════════════════════════════════════════════════════════════════════════
#  EXCEL
# ═══════════════════════════════════════════════════════════════════════════════

def mk_fill(hex_):
    return PatternFill(start_color=hex_, end_color=hex_, fill_type='solid')

def mk_border():
    t = Side(style='thin', color='BBBBBB')
    return Border(left=t, right=t, top=t, bottom=t)

def aplicar(c, fill=None, bold=False, color_font='000000',
            h_align='center', v_align='center', wrap=False, size=10, border=True):
    if fill:   c.fill = fill
    c.font = Font(bold=bold, color=color_font, size=size)
    c.alignment = Alignment(horizontal=h_align, vertical=v_align,
                             wrap_text=wrap)
    if border: c.border = mk_border()
    return c


def generar_excel(resultado, dias, f_ini, f_fin, ruta):

    # Paleta
    F_AZUL_OSC  = mk_fill('1F4E79')
    F_AZUL_MED  = mk_fill('2E75B6')
    F_LACIMA    = mk_fill('DEEAF1')
    F_RC        = mk_fill('FFF2CC')
    F_FALTA     = mk_fill('FF4C4C')
    F_DOM       = mk_fill('EEEEEE')
    F_SINSAL    = mk_fill('FFE0B2')
    F_OK        = mk_fill('E8F5E9')
    F_TITULO_LC = mk_fill('1A5276')
    F_TITULO_RC = mk_fill('7D6608')
    F_TOTAL     = mk_fill('2C3E50')
    F_EXTRA     = mk_fill('EDE7F6')   # lila claro para días con horas extras

    wb = Workbook()

    # ── HOJA 1: ASISTENCIA COMPLETA ──────────────────────────────────────────
    ws = wb.active
    ws.title = 'Asistencia'

    dias_col = list(dias)   # todos los días, incluyendo domingo
    n_dias   = len(dias_col)

    COL_EMPRESA = 1
    COL_ID      = 2
    COL_NOMBRE  = 3
    COL_ESTADO  = 4
    COL_HE      = 5   # columna horas extras totales del periodo
    COL_INICIO  = 6   # primer día

    # Columnas de percepciones (después de los días)
    PERCEPCIONES = [
        'SUELDO DIARIO', 'SBC', 'TIPO', 'TOTAL DIAS TRABAJADOS', 'HORAS EXTRAS',
        'SUELDO DIAS TRABAJADOS', 'SEPTIMO DIA', 'DESCANSO TRABAJADO',
        'PRIMA DOMINICAL', 'IMPORTE HORAS EXTRAS', 'DESCANSO (FESTIVOS) TRABAJADO',
        'FINIQUITO', 'ADICIONAL', 'MANEJO DE PANEL',
        'INCAPACIDAD PAGADA POR LA EMPRESA', 'PENDIENTE', 'VACACIONES',
        'PRIMA VACACIONAL', 'PRODUCTIVIDAD', 'TOTAL PERCEPCIONES', 'BASE GRAVABLE',
        'ISR', 'IMSS', 'SUELDO NETO'
    ]
    COL_PERCEP_INI = COL_INICIO + n_dias   # primera columna de percepciones

    # ── Fila 1: título ────────────────────────────────────────────────────────
    last_col = COL_PERCEP_INI + len(PERCEPCIONES) - 1
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=last_col)
    t = ws.cell(row=1, column=1,
                value=f'REPORTE DE ASISTENCIA Y PERCEPCIONES  |  {f_ini:%d/%m/%Y}  al  {f_fin:%d/%m/%Y}')
    aplicar(t, fill=F_AZUL_OSC, bold=True, color_font='FFFFFF', size=13, border=False)
    ws.row_dimensions[1].height = 26

    # ── Fila 2: encabezados fijos ─────────────────────────────────────────────
    ws.row_dimensions[2].height = 40
    for col, txt in [(COL_EMPRESA,'Empresa'),(COL_ID,'ID\nCONTPAQi'),
                     (COL_NOMBRE,'Nombre'),(COL_ESTADO,'Estado'),
                     (COL_HE,'HE\nPeriodo')]:
        c = ws.cell(row=2, column=col, value=txt)
        aplicar(c, fill=F_AZUL_MED, bold=True, color_font='FFFFFF', wrap=True)

    # Encabezados de días (incluye domingo con color distinto)
    F_DOM_HEAD = mk_fill('6B7280')
    for i, dia in enumerate(dias_col):
        es_dom = dia.weekday() == 6
        c = ws.cell(row=2, column=COL_INICIO + i,
                    value=f'{DIAS_ES[dia.weekday()]}\n{dia.day:02d}/{dia.month:02d}')
        aplicar(c, fill=F_DOM_HEAD if es_dom else F_AZUL_MED,
                bold=True, color_font='FFFFFF', wrap=True)

    # Encabezados de percepciones
    F_PERCEP_HEAD = mk_fill('1B5E20')
    for j, titulo in enumerate(PERCEPCIONES):
        c = ws.cell(row=2, column=COL_PERCEP_INI + j, value=titulo)
        aplicar(c, fill=F_PERCEP_HEAD, bold=True, color_font='FFFFFF',
                wrap=True, size=8)

    # ── Filas de empleados ────────────────────────────────────────────────────
    empresa_actual = None
    fila = 3

    # Paleta de colores para separadores de empresa (cíclica si hay más de 2)
    COLORES_SEP = ['1A5276', '7D6608', '145A32', '4A235A', '6E2F0E', '1B4F72']
    empresa_color_idx = {}

    # Ordenar por empresa (alfabético) y dentro de cada empresa por nombre
    resultado_ord = sorted(resultado, key=lambda r: (r['empresa'], r['nombre']))

    for emp in resultado_ord:

        # Separador de empresa
        if emp['empresa'] != empresa_actual:
            empresa_actual = emp['empresa']
            if empresa_actual not in empresa_color_idx:
                empresa_color_idx[empresa_actual] = len(empresa_color_idx) % len(COLORES_SEP)
            color_sep = COLORES_SEP[empresa_color_idx[empresa_actual]]
            ws.merge_cells(start_row=fila, start_column=1,
                           end_row=fila, end_column=last_col)
            c = ws.cell(row=fila, column=1,
                        value=f'  ▶  {empresa_actual.upper()}')
            aplicar(c, fill=mk_fill(color_sep), bold=True, color_font='FFFFFF',
                    h_align='left', size=11, border=False)
            ws.row_dimensions[fila].height = 18
            fila += 1

        ws.row_dimensions[fila].height = 42   # más alto para caber E/S/H
        # Color de fila: paleta cíclica para cualquier empresa
        COLORES_FILA = ['DEEAF1', 'FFF2CC', 'E8F5E9', 'F3E5F5', 'FBE9E7', 'E3F2FD']
        idx_color = empresa_color_idx.get(emp['empresa'], 0)
        bg = mk_fill(COLORES_FILA[idx_color % len(COLORES_FILA)])

        # Columnas fijas
        aplicar(ws.cell(row=fila, column=COL_EMPRESA, value=emp['empresa']),
                fill=bg, h_align='left')
        aplicar(ws.cell(row=fila, column=COL_ID,      value=emp['id']),      fill=bg)
        aplicar(ws.cell(row=fila, column=COL_NOMBRE,  value=emp['nombre']),
                fill=bg, h_align='left', bold=True)

        # Estado
        es_ok = emp['total_faltas'] == 0
        c_est = ws.cell(row=fila, column=COL_ESTADO, value=emp['estado'])
        aplicar(c_est,
                fill=F_OK if es_ok else F_FALTA,
                color_font='155724' if es_ok else 'FFFFFF',
                bold=True, wrap=True, h_align='left')

        # Horas extras del periodo
        he_tot = emp.get('total_extras', 0)
        c_he = ws.cell(row=fila, column=COL_HE,
                        value=f'{he_tot} HE' if he_tot else '-')
        aplicar(c_he,
                fill=mk_fill('7B1FA2') if he_tot else bg,
                color_font='FFFFFF' if he_tot else '555555',
                bold=bool(he_tot))

        # Celda por día
        for i, dia in enumerate(dias_col):
            info = emp['dias_info'].get(dia, {'estado':'?','entrada':'','salida':'',
                                              'horas':None,'extras':0})
            col  = COL_INICIO + i

            if info['estado'] == 'DOM':
                # Domingo no trabajado → gris vacío
                c = ws.cell(row=fila, column=col, value='')
                aplicar(c, fill=F_DOM, color_font='999999')

            elif info['estado'] == 'FALTA':
                c = ws.cell(row=fila, column=col, value='FALTA')
                aplicar(c, fill=F_FALTA, bold=True, color_font='FFFFFF')

            else:
                # OK o DOM_OK (domingo trabajado)
                es_dom_ok = info['estado'] == 'DOM_OK'
                entrada = info['entrada']
                salida  = info['salida']
                horas   = info.get('horas')
                extras  = info.get('extras', 0)
                sin_sal = salida == '(sin salida)'

                lineas = [f"E: {entrada}", f"S: {salida}"]
                if horas:
                    lineas.append(f"H: {horas}" + (f"  (+{extras} HE)" if extras else ""))
                if es_dom_ok:
                    lineas.append("(DOMINGO)")
                txt = "\n".join(lineas)

                if es_dom_ok:
                    cell_bg = mk_fill('FFE0F0')   # rosa para domingo trabajado
                elif extras:
                    cell_bg = F_EXTRA
                elif sin_sal:
                    cell_bg = F_SINSAL
                else:
                    cell_bg = bg

                c = ws.cell(row=fila, column=col, value=txt)
                aplicar(c,
                        fill=cell_bg,
                        wrap=True,
                        color_font='880E4F' if es_dom_ok else
                                   ('4A148C' if extras else ('BF360C' if sin_sal else '000000')))

        # ── Columnas de percepciones ──────────────────────────────────────────
        # Mapa nombre→letra de columna (para fórmulas)
        def letra(idx_percep):
            return get_column_letter(COL_PERCEP_INI + idx_percep)

        # Valores calculados (los manuales quedan vacíos)
        valores_percep = {
            'SUELDO DIARIO':          emp['salario'],
            'SBC':                    emp.get('sbc', 0),
            'TIPO':                   emp.get('tipo', ''),
            'TOTAL DIAS TRABAJADOS':  emp['dias_trabajados'],
            'HORAS EXTRAS':           emp['total_extras'],
            'SEPTIMO DIA':            emp['septimo_dia'],
            'PRIMA DOMINICAL':        emp['prima_dominical'],
            'IMPORTE HORAS EXTRAS':   emp['importe_he'],
        }

        # Índices clave (se recalculan automáticamente si cambia la lista)
        idx_sueldo_dt  = PERCEPCIONES.index('SUELDO DIAS TRABAJADOS')
        idx_productiv  = PERCEPCIONES.index('PRODUCTIVIDAD')
        idx_total_perc = PERCEPCIONES.index('TOTAL PERCEPCIONES')
        idx_base_grav  = PERCEPCIONES.index('BASE GRAVABLE')
        idx_prima_dom  = PERCEPCIONES.index('PRIMA DOMINICAL')
        idx_sbc        = PERCEPCIONES.index('SBC')
        idx_dias       = PERCEPCIONES.index('TOTAL DIAS TRABAJADOS')
        idx_sueldo_d   = PERCEPCIONES.index('SUELDO DIARIO')
        idx_isr        = PERCEPCIONES.index('ISR')
        idx_imss       = PERCEPCIONES.index('IMSS')
        idx_neto       = PERCEPCIONES.index('SUELDO NETO')

        # Letras de columna para fórmulas
        c_tp     = get_column_letter(COL_PERCEP_INI + idx_total_perc)
        c_pd     = get_column_letter(COL_PERCEP_INI + idx_prima_dom)
        c_bg     = get_column_letter(COL_PERCEP_INI + idx_base_grav)
        c_sbc    = get_column_letter(COL_PERCEP_INI + idx_sbc)
        c_dias   = get_column_letter(COL_PERCEP_INI + idx_dias)
        c_sueldo = get_column_letter(COL_PERCEP_INI + idx_sueldo_d)
        c_isr    = get_column_letter(COL_PERCEP_INI + idx_isr)
        c_imss   = get_column_letter(COL_PERCEP_INI + idx_imss)

        # Tipo del empleado (determina fórmula de ISR)
        tipo_emp = str(emp.get('tipo', '')).strip()
        es_eventual = tipo_emp == 'Eventual'

        for j, titulo in enumerate(PERCEPCIONES):
            col_p = COL_PERCEP_INI + j

            if titulo == 'SUELDO DIAS TRABAJADOS':
                # = Sueldo Diario × Total Días Trabajados
                valor = f"=ROUND({c_sueldo}{fila}*{c_dias}{fila},2)"

            elif titulo == 'TOTAL PERCEPCIONES':
                col_ini_f = get_column_letter(COL_PERCEP_INI + idx_sueldo_dt)
                col_fin_f = get_column_letter(COL_PERCEP_INI + idx_productiv)
                valor = f"=SUM({col_ini_f}{fila}:{col_fin_f}{fila})"

            elif titulo == 'BASE GRAVABLE':
                valor = f"={c_tp}{fila}-{c_pd}{fila}"

            elif titulo == 'ISR':
                if es_eventual:
                    # ISR Eventual = SBC × (Días + 1) × 4%
                    valor = (f"=ROUND({c_sbc}{fila}"
                             f"*({c_dias}{fila}+1)*0.04,2)")
                else:
                    # ISR Permanente = buscar en Tabla ISR por Base Gravable
                    # (Límite inf está en col A, Cuota Fija en col C, % en col D)
                    valor = (f"=IF({c_bg}{fila}<=0,0,"
                             f"ROUND(({c_bg}{fila}"
                             f"-VLOOKUP({c_bg}{fila},'Tabla ISR'!$A:$D,1,1))"
                             f"*VLOOKUP({c_bg}{fila},'Tabla ISR'!$A:$D,4,1)"
                             f"+VLOOKUP({c_bg}{fila},'Tabla ISR'!$A:$D,3,1),2))")

            elif titulo == 'IMSS':
                # IMSS = SBC × (Días+1) × 2.375%
                # + SI SBC >= 3×UMA (339.42): (SBC - 339.42) × (Días+1) × 0.4%
                valor = (f"=ROUND({c_sbc}{fila}"
                         f"*({c_dias}{fila}+1)*0.02375"
                         f"+IF({c_sbc}{fila}>={UMA_3}"
                         f",({c_sbc}{fila}-{UMA_3})*({c_dias}{fila}+1)*0.004,0),2)")

            elif titulo == 'SUELDO NETO':
                valor = f"=ROUND({c_tp}{fila}-{c_isr}{fila}-{c_imss}{fila},2)"

            elif titulo in valores_percep:
                valor = valores_percep[titulo]

            else:
                valor = None   # manual → vacío

            c = ws.cell(row=fila, column=col_p, value=valor)
            es_texto  = titulo in ('TIPO',)
            es_conteo = titulo in ('TOTAL DIAS TRABAJADOS', 'HORAS EXTRAS')
            es_negrita = titulo in ('TOTAL PERCEPCIONES', 'BASE GRAVABLE',
                                    'ISR', 'IMSS', 'SUELDO NETO')
            aplicar(c, fill=bg, h_align='center', bold=es_negrita)
            if not es_conteo and not es_texto:
                c.number_format = '"$"#,##0.00'

        fila += 1

    # ── Fila de totales ───────────────────────────────────────────────────────
    fila += 1
    fila_totales = fila
    ws.row_dimensions[fila].height = 22
    total_faltas = sum(e['total_faltas'] for e in resultado)
    total_extras = sum(e.get('total_extras', 0) for e in resultado)
    total_deducc = sum(e['deduccion']    for e in resultado)
    ws.merge_cells(start_row=fila, start_column=1, end_row=fila, end_column=3)
    c1 = ws.cell(row=fila, column=1, value='TOTALES')
    aplicar(c1, fill=F_TOTAL, bold=True, color_font='FFFFFF', h_align='right')
    c2 = ws.cell(row=fila, column=4,
                 value=f'{total_faltas} falta(s)  |  Deducción: ${total_deducc:,.2f}')
    aplicar(c2, fill=F_TOTAL, bold=True, color_font='FFFFFF', h_align='left')
    c3 = ws.cell(row=fila, column=5, value=f'{total_extras} HE')
    aplicar(c3, fill=F_TOTAL, bold=True, color_font='FFFFFF')

    # Totales por columna de percepción (suma de toda la columna con fórmula)
    primera_fila_datos = 3
    ultima_fila_datos  = fila_totales - 2   # -1 fila en blanco antes de totales
    for j, titulo in enumerate(PERCEPCIONES):
        col_p = COL_PERCEP_INI + j
        col_letra = get_column_letter(col_p)
        es_conteo = titulo in ('TOTAL DIAS TRABAJADOS', 'HORAS EXTRAS')
        c = ws.cell(row=fila, column=col_p,
                    value=f"=SUM({col_letra}{primera_fila_datos}:{col_letra}{ultima_fila_datos})")
        aplicar(c, fill=F_TOTAL, bold=True, color_font='FFFFFF')
        if not es_conteo:
            c.number_format = '"$"#,##0.00'

    # ── Anchos de columna ─────────────────────────────────────────────────────
    ws.column_dimensions[get_column_letter(COL_EMPRESA)].width = 11
    ws.column_dimensions[get_column_letter(COL_ID)].width      = 13
    ws.column_dimensions[get_column_letter(COL_NOMBRE)].width  = 36
    ws.column_dimensions[get_column_letter(COL_ESTADO)].width  = 42
    ws.column_dimensions[get_column_letter(COL_HE)].width      = 10
    for i in range(n_dias):
        ws.column_dimensions[get_column_letter(COL_INICIO + i)].width = 16
    for j in range(len(PERCEPCIONES)):
        ws.column_dimensions[get_column_letter(COL_PERCEP_INI + j)].width = 15

    ws.freeze_panes = get_column_letter(COL_INICIO) + '3'

    # ── HOJA 2: SOLO FALTAS (resumen para CONTPAQi) ───────────────────────────
    ws2 = wb.create_sheet('Faltas para CONTPAQi')

    ws2.merge_cells('A1:H1')
    t2 = ws2.cell(row=1, column=1,
                  value=f'FALTAS A CAPTURAR EN CONTPAQi  |  {f_ini:%d/%m/%Y} – {f_fin:%d/%m/%Y}')
    aplicar(t2, fill=F_AZUL_OSC, bold=True, color_font='FFFFFF', size=12, border=False)
    ws2.row_dimensions[1].height = 24

    heads2 = ['Empresa','ID CONTPAQi','Nombre','Días Faltados',
              'Fechas','Salario Diario','Deducción','HE Periodo']
    ws2.append(heads2)
    fila_h2 = ws2.max_row
    for col in range(1, len(heads2)+1):
        aplicar(ws2.cell(row=fila_h2, column=col),
                fill=F_AZUL_MED, bold=True, color_font='FFFFFF')

    con_faltas = [e for e in resultado_ord if e['total_faltas'] > 0]

    if not con_faltas:
        ws2.append(['✓ Sin faltas en el periodo'])
    else:
        for emp in con_faltas:
            faltas_list = [d for d, info in emp['dias_info'].items()
                           if info['estado'] == 'FALTA']
            fechas_str  = ', '.join(
                f"{DIAS_ES[d.weekday()]} {d.day:02d}/{d.month:02d}" for d in faltas_list
            )
            he = emp.get('total_extras', 0)
            ws2.append([
                emp['empresa'],
                emp['id'],
                emp['nombre'],
                emp['total_faltas'],
                fechas_str,
                emp['salario'],
                emp['deduccion'],
                f'{he} HE' if he else '-'
            ])
            fr  = ws2.max_row
            idx_c2 = empresa_color_idx.get(emp['empresa'], 0)
            bg2 = mk_fill(COLORES_FILA[idx_c2 % len(COLORES_FILA)])
            for col in range(1, len(heads2)+1):
                c = ws2.cell(row=fr, column=col)
                c.fill   = bg2
                c.border = mk_border()
                c.alignment = Alignment(vertical='center')
                if col == 7:
                    c.number_format = '"$"#,##0.00'
                if col == 8 and he:
                    c.fill = mk_fill('EDE7F6')
                    c.font = Font(bold=True, color='4A148C')

        # Total
        ws2.append([])
        fr_tot = ws2.max_row + 1
        ws2.cell(row=fr_tot, column=3, value='TOTAL').font = Font(bold=True)
        ws2.cell(row=fr_tot, column=4,
                 value=sum(e['total_faltas'] for e in con_faltas)).font = Font(bold=True)
        c_tot = ws2.cell(row=fr_tot, column=7,
                         value=sum(e['deduccion'] for e in con_faltas))
        c_tot.font          = Font(bold=True)
        c_tot.number_format = '"$"#,##0.00'
        he_tot = sum(e.get('total_extras',0) for e in con_faltas)
        ws2.cell(row=fr_tot, column=8,
                 value=f'{he_tot} HE').font = Font(bold=True)

    ws2.column_dimensions['A'].width = 11
    ws2.column_dimensions['B'].width = 14
    ws2.column_dimensions['C'].width = 38
    ws2.column_dimensions['D'].width = 14
    ws2.column_dimensions['E'].width = 52
    ws2.column_dimensions['F'].width = 15
    ws2.column_dimensions['G'].width = 14
    ws2.column_dimensions['H'].width = 12
    ws2.freeze_panes = 'A3'

    # ── HOJA 3: TABLA ISR (referencia para fórmulas VLOOKUP) ─────────────────
    ws3 = wb.create_sheet('Tabla ISR')

    # Encabezados
    heads3 = ['Límite Inferior', 'Límite Superior', 'Cuota Fija',
              '% sobre excedente del Límite Inferior']
    for j, h in enumerate(heads3, 1):
        c = ws3.cell(row=1, column=j, value=h)
        c.fill = mk_fill('1F4E79')
        c.font = Font(bold=True, color='FFFFFF', size=9)
        c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        c.border = mk_border()
    ws3.row_dimensions[1].height = 30

    # Datos de la tabla (% almacenado como decimal para que VLOOKUP los use directo)
    ISR_TABLA = [
        (0.00,      194.46,   0.00,       0.0192),
        (194.47,    1650.67,  3.71,       0.0640),
        (1650.68,   2900.87,  96.95,      0.1088),
        (2900.88,   3372.11,  232.96,     0.1600),
        (3372.12,   4037.32,  308.35,     0.1792),
        (4037.33,   8142.75,  427.56,     0.2136),
        (8142.76,   12834.08, 1304.45,    0.2352),
        (12834.09,  24502.45, 2407.86,    0.3000),
        (24502.46,  32669.91, 5908.35,    0.3200),
        (32669.92,  98009.66, 8521.94,    0.3400),
        (98009.67,  None,     30737.49,   0.3500),   # None = "En adelante"
    ]

    for i, (lim_inf, lim_sup, cuota, pct) in enumerate(ISR_TABLA, 2):
        sup_val = 'En adelante' if lim_sup is None else lim_sup
        for j, val in enumerate([lim_inf, sup_val, cuota, pct], 1):
            c = ws3.cell(row=i, column=j, value=val)
            c.alignment = Alignment(horizontal='center')
            c.border     = mk_border()
            c.font       = Font(size=9)
            # Formato
            if j == 4:
                c.number_format = '0.00%'
            elif j != 2 or lim_sup is not None:
                c.number_format = '#,##0.00'
            # Alternar color de fila
            c.fill = mk_fill('EFF6FF' if i % 2 == 0 else 'FFFFFF')

    ws3.column_dimensions['A'].width = 18
    ws3.column_dimensions['B'].width = 18
    ws3.column_dimensions['C'].width = 14
    ws3.column_dimensions['D'].width = 22

    # Nota explicativa debajo de la tabla
    nota_fila = len(ISR_TABLA) + 3
    c_nota = ws3.cell(row=nota_fila, column=1,
                       value='Tabla para cálculo semanal de ISR (Permanentes). '
                             'No modificar — las fórmulas del reporte la referencian automáticamente.')
    c_nota.font = Font(italic=True, size=8, color='888888')

    wb.save(ruta)
    print(f"\n  ✅  Excel generado: {ruta}")


# ═══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    print('=' * 60)
    print('  PROCESADOR DE NÓMINA  |  BioTime → CONTPAQi')
    print('  La Cima / RC')
    print('=' * 60)

    parser = argparse.ArgumentParser()
    parser.add_argument('biotime',  help='Archivo CSV de BioTime')
    parser.add_argument('--setup',  action='store_true')
    parser.add_argument('--inicio', help='DD/MM/YYYY')
    parser.add_argument('--fin',    help='DD/MM/YYYY')
    parser.add_argument('--salida', help='Nombre del Excel de salida')
    args = parser.parse_args()

    # Empleados CONTPAQi
    print('\n  Cargando empleados de CONTPAQi...')
    df_cp = cargar_contpaq()
    lc = len(df_cp[df_cp['Empresa']=='La Cima'])
    rc = len(df_cp[df_cp['Empresa']=='RC'])
    print(f'  → La Cima: {lc}  |  RC: {rc}  |  Total: {lc+rc}')

    # BioTime
    print(f'\n  Cargando BioTime: {args.biotime}...')
    if not os.path.exists(args.biotime):
        print(f'  ✗ No se encontró: {args.biotime}')
        sys.exit(1)
    df_bt = cargar_biotime(args.biotime)
    print(f'  → {df_bt["ID_BT"].nunique()} empleados  |  {len(df_bt)} registros  '
          f'|  {df_bt["Fecha"].min():%d/%m/%Y} – {df_bt["Fecha"].max():%d/%m/%Y}')

    # Mapeo
    if args.setup or not os.path.exists(ARCHIVO_MAPEO):
        df_mapeo = generar_mapeo(df_bt, df_cp)
        if args.setup:
            return
    else:
        df_mapeo = pd.read_csv(ARCHIVO_MAPEO, dtype=str)
        df_mapeo['CONTPAQ_Salario'] = pd.to_numeric(
            df_mapeo['CONTPAQ_Salario'], errors='coerce').fillna(0)
        df_mapeo = _añadir_sbc_si_falta(df_mapeo)
        df_mapeo = _añadir_tipo_si_falta(df_mapeo)
        print(f'\n  Mapeo cargado: {len(df_mapeo)} empleados')

    # Periodo
    if args.inicio and args.fin:
        f_ini = datetime.strptime(args.inicio, '%d/%m/%Y')
        f_fin = datetime.strptime(args.fin,    '%d/%m/%Y')
    else:
        f_ini = df_bt['Fecha'].min()
        f_fin = df_bt['Fecha'].max()
        print('  ℹ  Sin fechas → usando rango completo del BioTime')

    # Procesar
    resultado, dias = procesar(df_bt, df_mapeo, f_ini, f_fin)

    con_faltas = sum(1 for e in resultado if e['total_faltas'] > 0)
    total_dias = sum(e['total_faltas'] for e in resultado)
    total_ded  = sum(e['deduccion']    for e in resultado)
    print(f'\n  Resultado:')
    print(f'  → Empleados procesados:    {len(resultado)}')
    print(f'  → Con al menos una falta:  {con_faltas}')
    print(f'  → Total días de falta:     {total_dias}')
    print(f'  → Deducción total:         ${total_ded:,.2f}')

    # Excel
    if not args.salida:
        nominas_dir = os.path.join(SCRIPT_DIR, 'nominas')
        os.makedirs(nominas_dir, exist_ok=True)
        nombre = f"Nominas-{f_ini:%d}-{f_fin:%d}-{f_ini:%m}-{f_ini:%Y}.xlsx"
        args.salida = os.path.join(nominas_dir, nombre)
    generar_excel(resultado, dias, f_ini, f_fin, args.salida)

if __name__ == '__main__':
    main()
