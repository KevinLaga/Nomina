@echo off
title Procesador de Nomina - La Cima / RC

:: Verificar Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Python no esta instalado.
    echo.
    echo  Por favor:
    echo    1. Ve a https://python.org/downloads
    echo    2. Instala Python
    echo    3. Marca la casilla "Add Python to PATH"
    echo    4. Reinicia la computadora
    echo    5. Vuelve a abrir este archivo
    echo.
    pause
    exit /b 1
)

:: Instalar dependencias automaticamente si faltan
pip install pandas openpyxl -q --no-warn-script-location 2>nul

:: Abrir la aplicacion
python "%~dp0app.py" 2>nul

if %errorlevel% neq 0 (
    echo.
    echo  Ocurrio un error. Intentando reinstalar dependencias...
    pip install pandas openpyxl --force-reinstall -q
    python "%~dp0app.py"
)
